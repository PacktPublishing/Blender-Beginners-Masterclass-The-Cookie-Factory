ADDON_NAME = "3D Tudor Compositor"
NODE_GROUP_FILE = "nodegroup.blend"
NODE_GROUP_NAME = "3D Tudor Compositer 1.0"
CATEGORY = "3DT Compositor"