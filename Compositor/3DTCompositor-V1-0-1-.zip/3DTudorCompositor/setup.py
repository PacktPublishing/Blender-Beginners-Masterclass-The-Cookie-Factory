import bpy
import addon_utils
import os
from .const import *

class Add3DTudorCompositorOperator(bpy.types.Operator):
    bl_idname = "object.add3dtudorcompositor"
    bl_label = "Add3DTudorCompositor"

    def append_node_tree(self) -> bool:
        '''
        append node tree from nodetree.py
        '''

        # check if not appended yet
        if NODE_GROUP_NAME in bpy.data.node_groups: 
            return True

        # find path of addon
        path = None
        for mod in addon_utils.modules():
            if mod.bl_info['name'] == ADDON_NAME:
                path = mod.__file__

        if path == None: return False

        # get folder
        folder = os.path.dirname(path)

        # create path to .blend file containing needed group
        blend_file = os.path.join(folder, NODE_GROUP_FILE)
        with bpy.data.libraries.load(blend_file) as (data_from, data_to):
            print(data_from.node_groups)
            if NODE_GROUP_NAME in data_from.node_groups:
                bpy.ops.wm.append(filename=NODE_GROUP_NAME, directory=os.path.join(blend_file, "NodeTree", ""), check_existing=True)
                print("Node Tree added successfully")
                return True

        return False
    
    def setup_node_tree(self):
        '''
        Setup Compositor to use nodes, add Compositor node group and add all connections
        '''
        scene = bpy.data.scenes["Scene"]
        # use nodes
        scene.use_nodes = True
        # remove all nodes
        nodes = scene.node_tree.nodes
        for node in nodes:
            nodes.remove(node)
        # set cycles as render engine
        scene.render.engine = 'CYCLES'
        # enable background transparency
        scene.render.film_transparent = True

        # add all needed nodes
        render_layers = nodes.new('CompositorNodeRLayers')
        render_layers.location.x = 0
        output = nodes.new("CompositorNodeComposite")
        output.location.x = 500
        comp_group = nodes.new('CompositorNodeGroup')
        comp_group.node_tree = bpy.data.node_groups[NODE_GROUP_NAME]
        comp_group.location.x = 300

        # output connections
        conn = scene.node_tree.links
        conn.new(comp_group.outputs['Image Output'], output.inputs['Image'])
        conn.new(comp_group.outputs['Alpha Output'], output.inputs['Alpha'])

        # render layer -> 3DT comps connections
        # alpha
        conn.new(render_layers.outputs['Alpha'], comp_group.inputs['Alpha'])
        # mist
        scene.view_layers["ViewLayer"].use_pass_mist = True
        conn.new(render_layers.outputs['Mist'], comp_group.inputs['Mist'])
        # diffuse
        scene.view_layers["ViewLayer"].use_pass_diffuse_direct = True
        scene.view_layers["ViewLayer"].use_pass_diffuse_indirect = True
        scene.view_layers["ViewLayer"].use_pass_diffuse_color = True
        conn.new(render_layers.outputs['DiffDir'], comp_group.inputs['Diff Direct'])
        conn.new(render_layers.outputs['DiffInd'], comp_group.inputs['Diff Indirect'])
        conn.new(render_layers.outputs['DiffCol'], comp_group.inputs['Diff Color'])
        # glossy
        scene.view_layers["ViewLayer"].use_pass_glossy_direct = True
        scene.view_layers["ViewLayer"].use_pass_glossy_indirect = True
        scene.view_layers["ViewLayer"].use_pass_glossy_color = True
        conn.new(render_layers.outputs['GlossDir'], comp_group.inputs['Gloss Direct'])
        conn.new(render_layers.outputs['GlossInd'], comp_group.inputs['Gloss Indirect'])
        conn.new(render_layers.outputs['GlossCol'], comp_group.inputs['Gloss Color'])
        # transmission
        scene.view_layers["ViewLayer"].use_pass_transmission_direct = True
        scene.view_layers["ViewLayer"].use_pass_transmission_indirect = True
        scene.view_layers["ViewLayer"].use_pass_transmission_color = True
        conn.new(render_layers.outputs['TransDir'], comp_group.inputs['Transmission Direct'])
        conn.new(render_layers.outputs['TransInd'], comp_group.inputs['Transmission Indirect'])
        conn.new(render_layers.outputs['TransCol'], comp_group.inputs['Transmission Color'])
        # volume
        bpy.data.scenes['Scene'].view_layers['ViewLayer']['cycles']['use_pass_volume_direct'] = 1
        bpy.data.scenes['Scene'].view_layers['ViewLayer']['cycles']['use_pass_volume_indirect'] = 1
        render_layers.update()
        conn.new(render_layers.outputs['VolumeDir'], comp_group.inputs['Volume Direct'])
        conn.new(render_layers.outputs['VolumeInd'], comp_group.inputs['Volume Indirect'])
        # emission
        scene.view_layers["ViewLayer"].use_pass_emit = True
        conn.new(render_layers.outputs['Emit'], comp_group.inputs['Emission'])
        # environment
        scene.view_layers["ViewLayer"].use_pass_environment = True
        conn.new(render_layers.outputs['Env'], comp_group.inputs['Environment'])
        # AO
        scene.view_layers["ViewLayer"].use_pass_ambient_occlusion = True
        conn.new(render_layers.outputs['AO'], comp_group.inputs['AO'])
        # denoising
        bpy.data.scenes['Scene'].view_layers['ViewLayer']['cycles']['denoising_store_passes'] = True
        render_layers.update()
        conn.new(render_layers.outputs['Denoising Normal'], comp_group.inputs['Denoise Normal'])
        conn.new(render_layers.outputs['Denoising Albedo'], comp_group.inputs['Denoise Albedo'])

    def execute(self, context):
        if not self.append_node_tree(): 
            self.report({'ERROR'}, 'Error while importing Compositor node group.')
            return {'CANCELLED'}
        self.setup_node_tree()
        self.report({'INFO'}, "3DT Compositor setup was successfull.")

        # set default background type to none
        props = context.scene.threedt_comp_props
        props.bg_type = "none"

        return {'FINISHED'}