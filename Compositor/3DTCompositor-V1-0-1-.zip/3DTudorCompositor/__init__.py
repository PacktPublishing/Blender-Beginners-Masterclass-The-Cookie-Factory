bl_info = {
    "name": "3D Tudor Compositor",
    "author": "3D Tudor, Vladan Trhlik",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "location": "Compositor > 3DT Compositor",
    "description": "",
    "category": "Compositing",
}

import bpy
from .panels import *
from .panels_fx import *
from .setup import *
        
class NODE_EDITOR_PT_3D_Tudor_Compositor(bpy.types.Panel):
    '''
    Main addon panel containing all sub panels
    '''
    bl_space_type = "NODE_EDITOR"
    bl_region_type = "UI"
    bl_category = CATEGORY
    bl_label = "3D Tudor Compositor"
    bl_idname = "NODE_EDITOR_PT_3D_Tudor_Compositor"

    group_name = "3D Tudor Compositer 1.0"
    
    def __init__(self):
        super().__init__()
        if (self.group_name in bpy.data.node_groups):
            self.group = bpy.data.node_groups[self.group_name]
    
    def draw(self, context):
        self.layout.operator("object.add3dtudorcompositor", text="Setup Compositor")
       
subpanels = [NODE_EDITOR_PT_3D_Tudor_Background, NODE_EDITOR_PT_3D_Tudor_Mist,
            NODE_EDITOR_PT_3D_Tudor_Color, NODE_EDITOR_PT_3D_Tudor_Gloss,
            NODE_EDITOR_PT_3D_Tudor_Trans, NODE_EDITOR_PT_3D_Tudor_Volume,
            NODE_EDITOR_PT_3D_Tudor_Light, NODE_EDITOR_PT_3D_Tudor_Environment,
            NODE_EDITOR_PT_3D_Tudor_AO,
            NODE_EDITOR_PT_3D_Tudor_Props]
# subpanels = subpanels[:2]
       
def register():    
    bpy.utils.register_class(NODE_EDITOR_PT_3D_Tudor_Compositor)
    bpy.utils.register_class(Add3DTudorCompositorOperator)
    for s in subpanels + fx_panels:
        bpy.utils.register_class(s)
    # add properties
    bpy.types.Scene.threedt_comp_props = bpy.props.PointerProperty(type=NODE_EDITOR_PT_3D_Tudor_Props)

def unregister():
    bpy.utils.unregister_class(NODE_EDITOR_PT_3D_Tudor_Compositor)
    bpy.utils.unregister_class(Add3DTudorCompositorOperator)
    for s in subpanels + fx_panels:
        bpy.utils.unregister_class(s)
    # delete props
    del bpy.types.Scene.threedt_comp_props

if __name__ == "__main__":
    register()
    
